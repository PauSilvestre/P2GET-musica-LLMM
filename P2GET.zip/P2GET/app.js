var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

// Se carga el módulo de sqlite3
var sqlite3 = require('sqlite3');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);

//carga el modulo knex
// inicializan sqlite3

var db = require('knex')({
  client: 'sqlite3',
  connection: {
    filename: 'musica.sqlite'
  }
  }
);

// rutas predef
//app.use('/', indexRouter);
//app.use('/users', usersRouter);

//RUTAS DEL USUARIO

//ruta artists

app.get('/api/artists', function(req, res) {
    db.select('ar.id', 'ar.name')
        .from('artists as ar')
        .then( function(data) {
            res.json(data);
        });
});

//rutas albums
// todos

app.get('/api/albums', function(req, res) {
    db.select('a.id', 'a.title', 'a.image', 'a.description')
        .from('albums as a')
        .then( function(data) {
            res.json(data);
        });
});

//seleccion por id
app.get('/api/albums/:id', function(req, res) {
    //select id, title, img, descrip de albums
    //where id=parametro:id
    //como es un string lo convertimos a entero
    // porq el campo labums.id es entero,
    let id = parseInt(req.params.id);
    db.select('a.id', 'a.title', 'a.image', 'a.description')
        .from('albums as a')
        .where('a.id', id)
        .then( function(data) {
            res.json(data);
        });
});

//rutas songs
app.get('/api/songs', function(req, res) {
 // SELECT id idAlbum length
 //from song as s
 db.select('s.id', 's.album_id','s.title', 's.length')
     .from('songs as s')
     //.where('a.id', id)
  .then( function(data) {
    res.json(data);
  });
}
);

//pedir los datos completos a todas las canciones
//select s. id,title,length, a. title as album, g.name as 'group'
//JOIN artist as g on (a.iDArtists=ar.id)
app.get('/api/songs/all', function(req, res) {
    db.select('s.id', 's.title', 's.length', 'a.title as album', 'ar.name as artists')
        .from('songs as s')
        .join('albums as a', 's.album_id', 'a.id')
        .join('artists as ar', 'a.artist_id', 'ar.id')
        .then(function(data) {
            res.json(data);
        });
});

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
